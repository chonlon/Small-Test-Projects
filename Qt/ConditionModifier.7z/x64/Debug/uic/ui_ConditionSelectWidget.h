/********************************************************************************
** Form generated from reading UI file 'ConditionSelectWidget.ui'
**
** Created by: Qt User Interface Compiler version 5.9.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONDITIONSELECTWIDGET_H
#define UI_CONDITIONSELECTWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Form
{
public:
    QGridLayout *gridLayout;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QHBoxLayout *horizontalLayout;
    QWidget *condition_contents;
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QPushButton *close_button;
    QPushButton *add_button;

    void setupUi(QWidget *Form)
    {
        if (Form->objectName().isEmpty())
            Form->setObjectName(QStringLiteral("Form"));
        Form->resize(786, 140);
        Form->setMinimumSize(QSize(0, 140));
        Form->setMaximumSize(QSize(16777215, 140));
        Form->setStyleSheet(QStringLiteral(""));
        gridLayout = new QGridLayout(Form);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        scrollArea = new QScrollArea(Form);
        scrollArea->setObjectName(QStringLiteral("scrollArea"));
        scrollArea->setMinimumSize(QSize(0, 130));
        scrollArea->setMaximumSize(QSize(16777215, 130));
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QStringLiteral("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 766, 128));
        horizontalLayout = new QHBoxLayout(scrollAreaWidgetContents);
        horizontalLayout->setSpacing(0);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        condition_contents = new QWidget(scrollAreaWidgetContents);
        condition_contents->setObjectName(QStringLiteral("condition_contents"));

        horizontalLayout->addWidget(condition_contents);

        widget = new QWidget(scrollAreaWidgetContents);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setMinimumSize(QSize(45, 0));
        widget->setMaximumSize(QSize(45, 16777215));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 5);
        close_button = new QPushButton(widget);
        close_button->setObjectName(QStringLiteral("close_button"));
        close_button->setMaximumSize(QSize(35, 16777215));

        verticalLayout->addWidget(close_button, 0, Qt::AlignRight|Qt::AlignTop);

        add_button = new QPushButton(widget);
        add_button->setObjectName(QStringLiteral("add_button"));
        add_button->setMinimumSize(QSize(0, 40));
        add_button->setMaximumSize(QSize(45, 40));

        verticalLayout->addWidget(add_button, 0, Qt::AlignBottom);


        horizontalLayout->addWidget(widget);

        scrollArea->setWidget(scrollAreaWidgetContents);

        gridLayout->addWidget(scrollArea, 1, 0, 1, 2);


        retranslateUi(Form);

        QMetaObject::connectSlotsByName(Form);
    } // setupUi

    void retranslateUi(QWidget *Form)
    {
        Form->setWindowTitle(QApplication::translate("Form", "Form", Q_NULLPTR));
        close_button->setText(QApplication::translate("Form", "\345\205\263\351\227\255", Q_NULLPTR));
        add_button->setText(QApplication::translate("Form", "\346\267\273\345\212\240", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Form: public Ui_Form {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONDITIONSELECTWIDGET_H
