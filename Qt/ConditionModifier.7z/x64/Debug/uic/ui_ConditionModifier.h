/********************************************************************************
** Form generated from reading UI file 'ConditionModifier.ui'
**
** Created by: Qt User Interface Compiler version 5.9.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONDITIONMODIFIER_H
#define UI_CONDITIONMODIFIER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ConditionModifierClass
{
public:
    QVBoxLayout *main_layout;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QVBoxLayout *verticalLayout_2;
    QWidget *button_group_container;
    QVBoxLayout *verticalLayout;
    QPushButton *add_button;
    QPushButton *delete_button;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *ConditionModifierClass)
    {
        if (ConditionModifierClass->objectName().isEmpty())
            ConditionModifierClass->setObjectName(QStringLiteral("ConditionModifierClass"));
        ConditionModifierClass->resize(856, 257);
        main_layout = new QVBoxLayout(ConditionModifierClass);
        main_layout->setSpacing(6);
        main_layout->setContentsMargins(11, 11, 11, 11);
        main_layout->setObjectName(QStringLiteral("main_layout"));
        widget = new QWidget(ConditionModifierClass);
        widget->setObjectName(QStringLiteral("widget"));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        scrollArea = new QScrollArea(widget);
        scrollArea->setObjectName(QStringLiteral("scrollArea"));
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QStringLiteral("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 740, 219));
        verticalLayout_2 = new QVBoxLayout(scrollAreaWidgetContents);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        button_group_container = new QWidget(scrollAreaWidgetContents);
        button_group_container->setObjectName(QStringLiteral("button_group_container"));

        verticalLayout_2->addWidget(button_group_container);

        scrollArea->setWidget(scrollAreaWidgetContents);

        horizontalLayout->addWidget(scrollArea);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        add_button = new QPushButton(widget);
        add_button->setObjectName(QStringLiteral("add_button"));
        add_button->setMaximumSize(QSize(70, 1000));

        verticalLayout->addWidget(add_button);

        delete_button = new QPushButton(widget);
        delete_button->setObjectName(QStringLiteral("delete_button"));
        delete_button->setMaximumSize(QSize(70, 16777215));

        verticalLayout->addWidget(delete_button);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);


        horizontalLayout->addLayout(verticalLayout);


        main_layout->addWidget(widget);


        retranslateUi(ConditionModifierClass);

        QMetaObject::connectSlotsByName(ConditionModifierClass);
    } // setupUi

    void retranslateUi(QWidget *ConditionModifierClass)
    {
        ConditionModifierClass->setWindowTitle(QApplication::translate("ConditionModifierClass", "ConditionModifier", Q_NULLPTR));
        add_button->setText(QApplication::translate("ConditionModifierClass", "\346\267\273\345\212\240", Q_NULLPTR));
        delete_button->setText(QApplication::translate("ConditionModifierClass", "\345\210\240\351\231\244", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class ConditionModifierClass: public Ui_ConditionModifierClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONDITIONMODIFIER_H
